# ms-teams-indicator

![ms-teams-indicator](ms-teams-indicator.png)

![ms-teams-indicator-alert](ms-teams-indicator-alert.png)
